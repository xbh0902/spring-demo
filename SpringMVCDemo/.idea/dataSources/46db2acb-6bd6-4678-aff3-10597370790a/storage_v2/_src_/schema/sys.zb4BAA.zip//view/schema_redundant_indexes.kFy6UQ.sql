CREATE VIEW schema_redundant_indexes AS
  SELECT
    `redundant_keys`.`table_schema`                                                   AS `table_schema`,
    `redundant_keys`.`table_name`                                                     AS `table_name`,
    `redundant_keys`.`index_name`                                                     AS `redundant_index_name`,
    `redundant_keys`.`index_columns`                                                  AS `redundant_index_columns`,
    `redundant_keys`.`non_unique`                                                     AS `redundant_index_non_unique`,
    `dominant_keys`.`index_name`                                                      AS `dominant_index_name`,
    `dominant_keys`.`index_columns`                                                   AS `dominant_index_columns`,
    `dominant_keys`.`non_unique`                                                      AS `dominant_index_non_unique`,
    if((`redundant_keys`.`subpart_exists` OR `dominant_keys`.`subpart_exists`), 1, 0) AS `subpart_exists`,
    concat('ALTER TABLE `', `redundant_keys`.`table_schema`, '`.`', `redundant_keys`.`table_name`, '` DROP INDEX `',
           `redundant_keys`.`index_name`, '`')                                        AS `sql_drop_index`
  FROM (`sys`.`x$schema_flattened_keys` `redundant_keys`
    JOIN `sys`.`x$schema_flattened_keys` `dominant_keys`
      ON (((`redundant_keys`.`table_schema` = `dominant_keys`.`table_schema`) AND
           (`redundant_keys`.`table_name` = `dominant_keys`.`table_name`))))
  WHERE ((`redundant_keys`.`index_name` <> `dominant_keys`.`index_name`) AND (
    ((`redundant_keys`.`index_columns` = `dominant_keys`.`index_columns`) AND
     ((`redundant_keys`.`non_unique` > `dominant_keys`.`non_unique`) OR
      ((`redundant_keys`.`non_unique` = `dominant_keys`.`non_unique`) AND
       (if((`redundant_keys`.`index_name` = 'PRIMARY'), '', `redundant_keys`.`index_name`) >
        if((`dominant_keys`.`index_name` = 'PRIMARY'), '', `dominant_keys`.`index_name`))))) OR
    ((locate(concat(`redundant_keys`.`index_columns`, ','), `dominant_keys`.`index_columns`) = 1) AND
     (`redundant_keys`.`non_unique` = 1)) OR
    ((locate(concat(`dominant_keys`.`index_columns`, ','), `redundant_keys`.`index_columns`) = 1) AND
     (`dominant_keys`.`non_unique` = 0))));

